<?php
function swipe_word($atts) {
// Attributes
$atts = shortcode_atts(
array(
	'postid' => get_the_ID(),
), 
$atts
);
// Attributes in var
$post_id = $atts['postid']; 
ob_start();
?>

<style>
@font-face {
   font-family: FZChaoCuHei;
   src: url(https://dev.zhi.services/nrs/wp-content/themes/betheme-child/fonts/FZChaoCuHei-M10S.ttf);
}
@font-face {
   font-family: microsoft-yahei;
   src: url(https://dev.zhi.services/nrs/wp-content/themes/betheme-child/fonts/microsoft-yahei.ttf);
}
.wordCarousel, .wordCarousel div li {
        font-family: FZChaoCuHei;
        color: #231F20;
        text-align:center;
        font-weight:100;
    }
 /*   .wordCarousel div {
        overflow: hidden;
        position: relative;
        text-align: center;
        height: 90px;
        padding-top: 10px;
        margin-top: -10px;
    } 
    .wordCarousel div li {
        color: #231F20;
        font-weight: 700;
       padding: 0 10px;
        height: 45px;
        margin-bottom: 45px;
        display: block; 
    }
    .flip2 {
        -webkit-animation: flip2 10s cubic-bezier(0.23, 1, 0.32, 1.2) infinite;
        animation: flip2 10s cubic-bezier(0.23, 1, 0.32, 1.2) infinite;
    }
    @-webkit-keyframes flip2 {
        0%, 100% {
            margin-top: -90px;
        }
        20%, 55% {
            margin-top: -90px;
        }
        60%, 95% {
            margin-top: 0px;
        }
    }
    @keyframes flip2 {
        0%, 100% {
            margin-top: -90px;
        }
        20%, 55% {
            margin-top: -90px;
        }
        60%, 95% {
            margin-top: 0px;
        }
    } */
</style>

<h1 class="wordCarousel">    
    <div> 
        <ul class="flip2"> 
            <li>短信验证码<span style="color:#EE0404;">无法收到?</span></li>
            <li>通话短信都<span style="color:#EE0404;">没办法发送？</span></li>
            <li>客户<span style="color:#EE0404;">严重失去信心与耐心</span>吗？</li>
        </ul>
    </div>  
</h1>

<script>

// Get the list of <li> elements
const liElements = document.querySelectorAll('.wordCarousel li');

let currentIndex = 0;

// Function to show the current <li> element and hide the others
function showCurrentElement() {
  liElements.forEach((li, index) => {
    if (index === currentIndex) {
      li.style.display = 'block';
    } else {
      li.style.display = 'none';
    }
  });
}

// Function to switch to the next <li> element
function swipeNext() {
  currentIndex = (currentIndex + 1) % liElements.length;
  showCurrentElement();
}

// Function to switch to the previous <li> element
function swipePrevious() {
  currentIndex = (currentIndex - 1 + liElements.length) % liElements.length;
  showCurrentElement();
}

// Show the initial <li> element
showCurrentElement();

// Set an interval to automatically swipe every 6 seconds
setInterval(swipeNext, 3000);


</script>

<?php
return ob_get_clean();
}
add_shortcode('swipe_word','swipe_word');